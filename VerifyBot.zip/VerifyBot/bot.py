import json
import discord
from discord.ext import commands

# ==========================================
# Verify Bot - Made by Cenniff
# ==========================================

with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

TOKEN = config.get("token")
ROLE_ID = config.get("verified_role_id")

embed_cfg = config.get("embed", {})
button_cfg = config.get("button", {})

if not TOKEN:
    print("❌ Missing token in config.json")
    exit()

if not ROLE_ID:
    print("❌ Missing role ID in config.json")
    exit()

# INTENTS (IMPORTANT FIX)
intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

# ==========================================
# VERIFY BUTTON
# ==========================================

class VerifyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label=button_cfg.get("text", "Verify"),
        style=discord.ButtonStyle.success,
        custom_id="verify_button"
    )
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):

        role = interaction.guild.get_role(int(ROLE_ID))

        if role is None:
            await interaction.response.send_message("❌ Role not found.", ephemeral=True)
            return

        if role in interaction.user.roles:
            await interaction.response.send_message("⚠️ Already verified.", ephemeral=True)
            return

        try:
            await interaction.user.add_roles(role)
            await interaction.response.send_message("✅ Verified!", ephemeral=True)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ Bot role is below verified role.",
                ephemeral=True
            )

# ==========================================
# FIX: COMMAND PROCESSING (CRITICAL)
# ==========================================

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    await bot.process_commands(message)

# ==========================================
# READY
# ==========================================

@bot.event
async def on_ready():
    bot.add_view(VerifyView())

    print("=" * 40)
    print("Verify Bot Online")
    print("Made by Cenniff")
    print(f"Logged in as {bot.user}")
    print("=" * 40)

# ==========================================
# PANEL COMMAND
# ==========================================

@bot.command()
@commands.has_permissions(administrator=True)
async def verifypanel(ctx):

    embed = discord.Embed(
        title=embed_cfg.get("title", "VERIFY"),
        description=embed_cfg.get("description", ""),
        color=int(embed_cfg.get("color", "#5865F2").replace("#", "0x"), 16)
    )

    if embed_cfg.get("thumbnail"):
        embed.set_thumbnail(url=embed_cfg["thumbnail"])

    if embed_cfg.get("image"):
        embed.set_image(url=embed_cfg["image"])

    embed.set_footer(text=embed_cfg.get("footer", "Made by Cenniff"))

    await ctx.send(embed=embed, view=VerifyView())

# ==========================================
# RUN
# ==========================================

bot.run(TOKEN)